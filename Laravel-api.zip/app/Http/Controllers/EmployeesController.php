<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeesController extends Controller
{
    // gets all Employees
    public function index(){
        return response()->json(Employee::all(), 200);
    }

    // gets a single employee
    public function show(int $id){
        $employee = Employee::find($id);
        if(is_null($employee)){
            return response()->json(['message' => 'Employee Not Found'], 404);
        }else{
            return response()->json($employee, 200);
        }
    }

    // create Employee 
    public function store(Request $request){
        $employee = Employee::create($request->all());
        return response($employee, 201);
    }
    
    // update employee
    public function update(int $id, Request $request){
        $employee = Employee::find($id);
        if(is_null($employee)){
            return response()->json(['message' => 'Employee Not Found'], 400);
        }else{
            return response($employee->update($request->all()), 201);
        }
    }

    // delete employee
    
    public function destroy(int $id){
        $employee = Employee::find($id);
        if(is_null($employee)){
            return response()->json(['message' => 'Employee Not Found'], 404);
        }else{
            return response()->json($employee->destroy($id), 204);
        }
    }
}
